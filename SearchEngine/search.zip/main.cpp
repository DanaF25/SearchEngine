/**------------------------------------------
    Project 2: Search Engine
    Course: CS 251, Fall 2023
    System: Visual Studio Code and Windows 10
    Student Author: Dana Fakhreddine
 ---------------------------------------------**/

// This is a .cpp file you will edit and turn in.

// Remove starter comments and add your own
// comments on each function and on complex code sections.

#include <string>
#include <iostream>
#include "search.h"
#include <map>
using namespace std;


//testing cleanToken
void testingCleanToken(){
  cout<<"testing clean token"<<endl;
  string firstTest = "././././././././dog???????????";
  string answer1 = "dog";
  string secondTest = ",,,,,,banana.bread!!!!";
  string secondAnswer = "banana.bread";
  string thirdTest = "+++++?????CS___251--------";
  string thirdAnswer = "cs___251";
  string fourthTest = "+++";
  string fourthAnswer = "";

  cout<<"string"<<firstTest<<" answer: "<<answer1<<" students solution: "<<cleanToken(firstTest)<<endl;
  cout<<"string"<<secondTest<<" answer: "<<secondAnswer<<" students solution: "<<cleanToken(secondTest)<<endl;
  cout<<"string"<<thirdTest<<" answer: "<<thirdAnswer<<" students solution: "<<cleanToken(thirdTest)<<endl;
  cout<<"string"<<fourthTest<<" answer: "<<fourthAnswer<<" students solution: "<<cleanToken(fourthTest)<<endl;
}

//print all set<string>
void printSolutionsAndAnswer(set<string> print){
  for(auto e: print){
    cout<<e<<endl;
  }
}

//testing gatherTokens 
void testingGatherTokens(){
  cout<<"testing gatherTokens"<<endl;
  string str1 = "Hello! world... CS!! is--- fun^^";
  string str2 = "PLL.. TVD$$$ ST!!! Shadow and bone:)";
  string str3 = "Pop!! ..jazz.band??? rock,music rap>>>";
  string str4 = ".";
  
  set<string> answer1 = {"cs", "fun", "hello", "is", "world"};
  set<string> answer2 = {"and", "bone", "pll", "shadow", "st", "tvd"};
  set<string> answer3 = {"jazz.band", "pop", "rap", "rock,music"};
  set<string> answer4 = {""};
  //testing first string
  cout<<"string: "<<str1<<endl<<" answer should be: ";
  printSolutionsAndAnswer(answer1);
  cout<<" students solution: ";
  printSolutionsAndAnswer(gatherTokens(str1));

  //testing second string
  cout<<"string: "<<str2<<endl<<" answer should be: ";
  printSolutionsAndAnswer(answer2);
  cout<<" students solution: ";
  printSolutionsAndAnswer(gatherTokens(str2));

  //testing third string
  cout<<"string: "<<str3<<endl<<" answer should be: ";
  printSolutionsAndAnswer(answer3);
  cout<<" students solution: ";
  printSolutionsAndAnswer(gatherTokens(str3));

  //testing third string
  cout<<"string: "<<str4<<endl<<" answer should be: ";
  printSolutionsAndAnswer(answer4);
  cout<<" students solution: ";
  printSolutionsAndAnswer(gatherTokens(str4));
}

//printing out map keys and values
void printMap(map<string, set<string>> index){
  for(auto e: index){
    cout<<e.first<<"-->";
    for(auto &j: e.second){
      cout<<j<<" ";
    }
    cout<<endl;
    }
}

//testing buildIndex
void testingBuildIndex(){
  map<string, set<string>> index1;
  map<string, set<string>> index2;

  string filename1 = "tiny.txt";
  string filename2 = "cplusplus.txt";
  string filename3 = "";

  int count1;
  int count2;

  cout<<"for tiny.txt"<<endl;
  count1 = buildIndex(filename1, index1);
  printMap(index1);
  cout<<"count: "<<count1<<endl;

  cout<<"for cplusplus.txt"<<endl;
  count2 = buildIndex(filename2, index2);
  printMap(index2);
  cout<<"count: "<<count2<<endl;
  
  cout<<"for empty string"<<endl;
  buildIndex(filename3, index2);
}

//testing quereyMatches
void testingQueryMatches(){
  map<string, set<string>> index;
  string sentence1 = "milk +red";
  string sentence2 = "red -fish";
  string sentence3 = "eggs not";

  set<string> one;
  set<string> two;
  set<string> three;

  buildIndex("tiny.txt", index);

  cout<<"first sentence"<<endl;
  printSolutionsAndAnswer(findQueryMatches(index, sentence1));
  cout<<"second sentence"<<endl;
  printSolutionsAndAnswer(findQueryMatches(index, sentence2));
  cout<<"third sentence"<<endl;
  printSolutionsAndAnswer(findQueryMatches(index, sentence3));
}

//testing searcEngine function
void testSearchEngine(){
  searchEngine("tiny.txt");
  searchEngine("cplusplus.txt");
}

int main() {
    
    // Use this function to call and test the functions you write inside of
    // search.h.  If you do not call the functions here, nothing will run.

    // testingCleanToken();
    // cout<<endl;
    // testingGatherTokens();
    testingBuildIndex();
    //testingQueryMatches();

    string filename;
    getline(cin, filename);
    searchEngine(filename);
    
    return 0;
}

